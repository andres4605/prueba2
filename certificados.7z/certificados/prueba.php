<p>fecha de inicio:  <input type="date" name="cumpleanios" step="1" min="2019-01-01" max="2025-12-31" value="<?php echo date("Y-m-d");?>">
</p>

Fecha nacimiento: <input type="date" name="cumpleanios" step="1" min="2013-01-01" max="2013-12-31" value="2013-01-01">