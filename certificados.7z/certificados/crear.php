<?php
include 'funciones.php';

if (isset($_POST['submit'])) {
  $resultado = [
    'error' => false,
    'mensaje' => 'El usuario ' . $_POST['nombre'] . ' ha sido agregado con éxito' 
  ];
  $config = include 'config.php';

  try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], $config['db']['pass'], $config['db']['options']);

    $firmante = array(
      "nombre"   => $_POST['nombre'],
      "apellido" => $_POST['apellido'],
      "ci"    => $_POST['ci'],
      "cargo"     => $_POST['cargo'],
      "email"     => $_POST['email'],
      "inicio"     => $_POST['inicio'],
      "fin"     => $_POST['fin'],
    );
    
    $consultaSQL = "INSERT INTO firmante (nombre, apellido, ci, cargo, email, inicio, fin)";
    $consultaSQL .= "values (:" . implode(", :", array_keys($firmante)) . ")";
    
    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute($firmante);

  } catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
  }
}
?>

<?php include "templates/header.php"; ?>

<?php
if (isset($resultado)) {
  ?>
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-<?= $resultado['error'] ? 'danger' : 'success' ?>" role="alert">
          <?= $resultado['mensaje'] ?>
        </div>
      </div>
    </div>
  </div>
  <?php
}
?>
<?php include "templates/header.php"; ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="mt-4">Registrar Usuario</h2>
      <hr>
      <form method="post">
        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input type="text" name="nombre" id="nombre" class="form-control">
        </div>
        <div class="form-group">
          <label for="apellido">Apellido</label>
          <input type="text" name="apellido" id="apellido" class="form-control">
        </div>
         <div class="form-group">
          <label for="email">Carnet de Identidad</label>
          <input type="text" name="ci" id="ci" class="form-control">
        </div>
        <div class="form-group">
          <label for="email">Cargo</label>
          <input type="text" name="cargo" id="cargo" class="form-control">
        </div>
        <div class="form-group">
          <label for="edad">Email</label>
          <input type="email" name="email" id="email" class="form-control">
        </div>
        <p>
          Inicio de la Firma:  <input type="date" name="inicio" step="1" min="2019-01-01" max="2025-12-31" value="<?php echo date("Y-m-d");?>">
          Fin de la Firma:  <input type="date" name="fin" step="1" min="2019-01-01" max="2025-12-31" value="<?php echo date("Y-m-d");?>">
        </p>
        <div class="form-group">
          <input type="submit" name="submit" class="btn btn-primary" value="Enviar">
          <a class="btn btn-primary" href="index.php">Regresar al inicio</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include "templates/footer.php"; ?>